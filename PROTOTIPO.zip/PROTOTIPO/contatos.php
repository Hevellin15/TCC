<?php
require_once "../conexao/conn.php";
$sqlListarContatos = "SELECT * FROM contatos";
$stmt = $conn->query($sqlListarContatos);
$contatos = $stmt->fetchAll(PDO::FETCH_OBJ);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div>
        <a href="#">Novo Contato</a>
    </div>
    <table>
        <theader>
            <tr>
                <th>ID</th> 
                <th>Nome</th> 
                <th>Email</th> 
                <th>Telefone</th> 
                <th>Sexo</th> 
            </tr>
        </theader>
        <tbody>
            <?php
            $rs = mysqli_query($conexao,$sql) or die("Erro ao executar a consuta" . mysqli_error($conexao));
            while($informacoes = mysqli_fetch_assoc($rs)){
            ?>
            <tr>
                <td><?=$informacoes["idContatos"] ?></td>
                <td><?=$informacoes["nome"] ?></td>
                <td><?=$informacoes["email"] ?></td>
                <td><?=$informacoes["telefone"] ?></td>
                <td><?=$informacoes["sexo"] ?></td> 
            </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
</body>
</html>