<?php

require_once '../conexao/config.php';

extract($_POST);

$sqlInsertCliente = "INSERT INTO casdastrarcliente VALUES(0, :nome, :email, :senha)"; 
$stmt = $conn->prepare($sqlInsertCliente);
$stmt->bindValue(':nome', $nome);
$stmt->bindValue(':email', $email);
$stmt->bindValue(':senha', $senha);
$stmt->execute();
?>
<script>alert('Produto cadastrado com sucesso. ')</script>
<meta http-equiv="refresh" content="0; url=../../../cadastrar.html">

?>