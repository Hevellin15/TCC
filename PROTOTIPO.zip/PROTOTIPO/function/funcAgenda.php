<?php

require_once '../conexao/config.php';

extract($_POST);

$sqlInsertAgendamento = "INSERT INTO agenda VALUES(0, :horario, :dia, :servico, :telefone, :email)"; 
$stmt = $conn->prepare($sqlInsertAgendamento);
$stmt->bindValue(':horario', $horario);
$stmt->bindValue(':dia', $dia);
$stmt->bindValue(':servico', $servico);
$stmt->bindValue(':telefone', $telefone);
$stmt->bindValue(':email', $email);
$stmt->execute();
?>
<script>alert('Agendamento realizado com sucesso. ')</script>
<meta http-equiv="refresh" content="0; url=../../../agenda.html">