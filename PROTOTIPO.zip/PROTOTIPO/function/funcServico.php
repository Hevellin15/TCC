<?php

require_once '../conexao/config.php';

extract($_POST);

$sqlInsertServico = "INSERT INTO cadservico VALUES(0, :nome, :valor, :descricao)"; 
$stmt = $conn->prepare($sqlInsertServico);
$stmt->bindValue(':nome', $nome);
$stmt->bindValue(':valor', $valor);
$stmt->bindValue(':descricao', $descricao);
$stmt->execute();
?>
<script>alert('Servico cadastrado com sucesso. ')</script>
<meta http-equiv="refresh" content="0; url=../../../administrador/cadServicos.php">

?>