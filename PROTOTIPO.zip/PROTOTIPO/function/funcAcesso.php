<?php

require_once '../conexao/config.php';

extract($_POST);

$sqlInsertAcessar = "INSERT INTO acesso VALUES(0, :nome, :valor, :descricao)"; 
$stmt = $conn->prepare($sqlInsertAcessar);
$stmt->bindValue(':email', $email);
$stmt->bindValue(':senha', $senha);
$stmt->execute();
?>
<script>alert('É bom te ver adminitrador! ')</script>
<meta http-equiv="refresh" content="0; url=../../../administrador/acesso.html">

?>