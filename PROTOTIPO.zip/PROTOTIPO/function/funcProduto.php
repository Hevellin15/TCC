<?php

require_once '../conexao/config.php';

extract($_POST);

$sqlInsertAgendamento = "INSERT INTO cadproduto VALUES(0, :nome, :valor, :descricao)"; 
$stmt = $conn->prepare($sqlInsertAgendamento);
$stmt->bindValue(':nome', $nome);
$stmt->bindValue(':valor', $valor);
$stmt->bindValue(':descricao', $descricao);
$stmt->execute();
?>
<script>alert('Produto cadastrado com sucesso. ')</script>
<meta http-equiv="refresh" content="0; url=../../../administrador/cadProdutos.php">

?>