<?php

require_once '../../conexao/conn.php';

extract($_POST);

$sqlInsertContato = "INSERT INTO contatos VALUES(0, :nome, :email, :telefone, :sexo, :contatoFrequente)"; 
$stmt = $conn->prepare($sqlInsertContatos); 
$stmt->bindValue(':nome', $nome);    
$stmt->bindValue(':email', $email);
$stmt->bindValue(':telefone', $telefone);
$stmt->bindValue(':sexo', $sexo);
$stmt->execute();
?>
<script>alert('Novo contato cadastrado com sucesso. ')</script>
<meta http-equiv="refresh" content="0; url=../contatos.php">