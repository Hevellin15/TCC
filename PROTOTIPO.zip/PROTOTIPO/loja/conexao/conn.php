<?php

$conn = new PDO('mysql:hostname=localhost;dbname=cadastro','root','');

?>