<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda de Salão</title>
</head>
<body>
    <header>
        <h1>Agenda de Salão</h1>
        <nav>
            <a href="index.php?menuAg=home">Home</a>
            <a href="index.php?menuAg=loja">Loja</a>
            <a href="index.php?menuAg=perfil">Contatos</a>
            <a href="index.php?menuAg=sobrenos">Sobre Nós</a>
        </nav>
    </header>
</body>
</html>