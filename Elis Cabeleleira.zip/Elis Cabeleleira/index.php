<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="styleheet" href="assets/css/style.css">
    <title>Login</title>
</head>
<body>
    <div class="container">
        <div class="content fist-content">
            <div class="first column"></div>
            <div class="second column">
                <h2 class="title">Crie uma conta</h2>
                <p class="description">Coloque seu email para se cadastrar</p>
                <form class="form">
                    <input type="text" placeholder="Name">
                    <input type="email" placeholder="Email">
                    <input type="password" placeholder="Password">
                    <button class="btn">Sing Up</button>
                </form>
            </div>
        </div>
        <div class="content second-content"></div>
    </div>
</body>
</html>