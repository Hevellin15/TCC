-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 21-Out-2024 às 13:19
-- Versão do servidor: 8.0.18
-- versão do PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `agendamrentosalao`
--
CREATE DATABASE IF NOT EXISTS `agendamrentosalao` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `agendamrentosalao`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `acesso`
--

DROP TABLE IF EXISTS `acesso`;
CREATE TABLE IF NOT EXISTS `acesso` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `senha` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `acesso`
--

INSERT INTO `acesso` (`id_admin`, `email`, `senha`) VALUES
(1, 'noobBunny@gmail.com', ''),
(2, 'noobBunny@gmail.com', NULL),
(3, 'noobBunny@gmail.com', NULL),
(4, 'noobBunny@gmail.com', NULL),
(5, 'bonbon@gmail.com', NULL),
(6, 'bonbon@gmail.com', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `agenda`
--

DROP TABLE IF EXISTS `agenda`;
CREATE TABLE IF NOT EXISTS `agenda` (
  `id_agenda` int(11) NOT NULL AUTO_INCREMENT,
  `horario` varchar(10) NOT NULL,
  `dia` date NOT NULL,
  `servico` varchar(20) NOT NULL,
  `telefone` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id_agenda`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `agenda`
--

INSERT INTO `agenda` (`id_agenda`, `horario`, `dia`, `servico`, `telefone`, `email`) VALUES
(8, '14:40', '2024-09-30', 'dtuc', 'gfh', 'txutfrx@ytfy'),
(9, '09:29', '2024-10-15', 'Tintura', '15 9999-9999', 'bonbon@gmail.com'),
(10, '09:31', '2024-10-15', 'Tintura', '15 9999-9999', 'bo'),
(11, '09:32', '2024-10-15', 'Tintura', '15 9999-9999', 'bonbon@gmail.com'),
(12, '14:00', '2024-10-08', 'Corte', '15 9999-9999', 'bonbon@gmail.com');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadproduto`
--

DROP TABLE IF EXISTS `cadproduto`;
CREATE TABLE IF NOT EXISTS `cadproduto` (
  `id_servico` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) NOT NULL,
  `valor` varchar(10) NOT NULL,
  `imagem` text NOT NULL,
  PRIMARY KEY (`id_servico`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cadproduto`
--

INSERT INTO `cadproduto` (`id_servico`, `nome`, `valor`, `imagem`) VALUES
(5, 'outra mulher', '9640739856', '6716542415d32.jpg'),
(4, 'mulher', '0000', '671652e340946.jpg'),
(6, 'produto 6', '5467', '671654526490c.jpeg'),
(7, 'coida', '43635', '671654729c9eb.jpeg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadservico`
--

DROP TABLE IF EXISTS `cadservico`;
CREATE TABLE IF NOT EXISTS `cadservico` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) NOT NULL,
  `valor` varchar(10) NOT NULL,
  `descricao` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cadservico`
--

INSERT INTO `cadservico` (`id`, `nome`, `valor`, `descricao`) VALUES
(1, 'Sabonete Vermelho', '10,99', 'Feito para pele e deixa-la mais macia'),
(2, 'Sobrancelha', '10,99', 'ghjghj'),
(3, 'Sobrancelha', '10,99', 'ghjghj'),
(4, 'Sobrancelha', '10,99', 'ghjghj'),
(5, 'Sobrancelha', '10,99', 'ghjghj');

-- --------------------------------------------------------

--
-- Estrutura da tabela `casdastrarcliente`
--

DROP TABLE IF EXISTS `casdastrarcliente`;
CREATE TABLE IF NOT EXISTS `casdastrarcliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `senha` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `casdastrarcliente`
--

INSERT INTO `casdastrarcliente` (`id`, `nome`, `email`, `senha`) VALUES
(1, 'Luca', 'bonbon@gmail.com', '123'),
(2, 'Bonbon', 'bonbon@gmail.com', '987');

-- --------------------------------------------------------

--
-- Estrutura da tabela `logincliente`
--

DROP TABLE IF EXISTS `logincliente`;
CREATE TABLE IF NOT EXISTS `logincliente` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `senha` varchar(50) NOT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `logincliente`
--

INSERT INTO `logincliente` (`id_cliente`, `email`, `senha`) VALUES
(1, 'bonbon@gmail.com', '123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
