<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Login - Administrador</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <div class="left">
            <h2>Bem Vindo de Volta</h2>
            <br>
            <h3>ADMINISTRADOR</h3>
            <br>
            <div class="form-container">
                <form action="../function/funcAcesso.php" method="post">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="exemplo@gmail.com" required> 
                    
                    <label for="password">Senha</label>
                    <input type="password" id="password" name="password" placeholder="exemplo123" required>
                    
                    <button type="submit">Acessar</button>
                    
                </form>
            </div>
        </div>
        <div class="right">
        <img src="../assets/img/logo.jpeg" alt="logo">
        </div>
    </div>
</body>
</html>


<!-- <!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Login - Administrador</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <div class="left">
            <h2>Bem Vindo de Volta</h2>
            <h3>ADMINISTRADOR</h3>
            <div class="form-container">
                <form action="../function/funcAcesso.php" method="post">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="Email" required>
                    
                    <label for="password">Senha</label>
                    <input type="password" id="password" name="password" placeholder="Senha" required>
                    
                    <button type="submit">Acessar</button>
                </form>
            </div>
        </div>
        <div class="right">
        <img src="../assets/img/logo.jpeg" alt="logo">
        </div>
    </div>
</body>
</html> -->
