<?php
require_once "../conexao/config.php";
$sqlListarClientes = "SELECT * FROM agenda";
$stmt = $conn->query($sqlListarClientes);
$clientes = $stmt->fetchAll(PDO::FETCH_OBJ);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Horário dos Clientes</title>
  <link rel="stylesheet" href="../assets/css/agendaAdm.css">
</head>
<body>

  
    <nav class="menu">
        <div class="sepa">
        <a href="../administrador/cadProdutos.php">Add Produtos</a>
        <a href="../administrador/cadServicos.php">Add Serviço</a>
        <a href="../administrador/agendaAdm.php">Agenda</a>
        </div>
    </nav>
  

  <div class="container">
    <h2>Horário dos Clientes</h2>

    <div class="search-bar">
      <input type="text" placeholder="Encontre cliente">
      <button>🔍</button>
    </div>
    <table class="table table-striped table-dark">
            <thead>
              <tr>
                <td scope="col">#</td>
                <td scope="col">Hora</td>
                <td scope="col">Dia</td>
                <td scope="col">Serviço</td>
                <td scope="col">Telefone</td>
                <td scope="col">E-mail</td>
              </tr>
            </thead>
            <tbody>
              <?php
                foreach ($clientes as $agenda) {
              ?> 
                <tr>
                  <td><?= $agenda->id_agenda; ?></td> 
                  <td><?= $agenda->horario; ?></td>
                  <td><?= $agenda->dia; ?></td>
                  <td><?= $agenda->servico; ?></td>
                  <td><?= $agenda->telefone; ?></td>
                  <td><?= $agenda->email; ?></td>
                </tr>
              <?php
                }
              ?>       
            </tbody>
          </table>
  </div>
</body>
</html>