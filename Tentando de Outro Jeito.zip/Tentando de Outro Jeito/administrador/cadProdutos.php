<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Produtos</title>
    <link rel="stylesheet" href="../assets/css/cadProdutos.css">
</head>
<body>
    <nav class="menu">
        <button type="button" class="btn btn-primiry" id="btn"><a href="./cadServicos.php">Add Serviços</a></button>
        <li><a href="#">Elis Cabelelira</a></li>
    </nav>
        <div class="container">
            <form action="../function/funcProduto.php" enctype="multipart/form-data" method="post">
                <h1>Cadastrar Produtos</h1>
                <input type="file" id="produtoimg" name="produtoimg">
                <label for="name">Nome</label>
                <input type="text" name="nome" placeholder="Nome">
                
                <label for="valor">Valor</label>
                <input type="text" name="valor" placeholder="Valor">

            <div class="botoes">
                <button type="submit" class="delete-btn">Cancelar</button>
                <button type="submit" class="save-btn">Confirmar</button>
            </div>
            </form>
        </div>
    </header>
</body>
</html>