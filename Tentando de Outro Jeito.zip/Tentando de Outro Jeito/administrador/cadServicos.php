<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Serviços</title>
    <link rel="stylesheet" href="../assets/css/cadServiço.css">
</head>
<body>
    <nav class="menu">

        <button type="button" class="btn btn-primiry" id="btn"> <a href="./cadProdutos.php">Add Produto</a></button>
        <li>Elis Cabelelira</li>
    </nav>
        <div class="container">
            <form enctype = "multipart/form-data" action="../function/funcServico.php" method="post">
                <h1>Cadastrar Serviços</h1>
                <input type="file" id="servicoimg" name="servicoimg">
                <label for="name">Nome</label>
                <input type="text" name="nome" placeholder="Serviço">

                <label for="valor">Valor</label>
                <input type="text" name="valor" placeholder="Valor">

            <div class="botoes">
                <button type="submit" class="delete-btn">Cancelar</button>
                <button type="submit" class="save-btn">Confirmar</button>
            </div>
            </form>
        </div>
    </header>
</body>
</html>