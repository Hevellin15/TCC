<?php

require_once '../conexao/config.php';
extract($_POST);

// Define constantes
$target_dir = "../assets/img/PRODUTOS/";
$file_size_limit = 2000000; // 2 MB
$allowed_types = ['jpg', 'jpeg', 'png'];
$errorMsg = "";
$successMsg = "";

// Verifica se o arquivo foi enviado
if (isset($_FILES["servicoimg"])) {
    $imageFileType = strtolower(pathinfo($_FILES["servicoimg"]["name"], PATHINFO_EXTENSION));
    $nomeArquivo = uniqid() . "." . $imageFileType;
    $target_file = $target_dir . $nomeArquivo;

    // Verifica o tipo de arquivo
    if (!in_array($imageFileType, $allowed_types)) {
        echo("Apenas arquivos JPG, JPEG e PNG são permitidos.");
    }

    // Verifica o tamanho do arquivo (max 2mb, limite padrão do php,)
    if ($_FILES["servicoimg"]["size"] > $file_size_limit) {
        echo("A imagem é muito grande.");
    }

    // Verifica se o arquivo é uma imagem (ele )
    if (getimagesize($_FILES["servicoimg"]["tmp_name"]) === false) {
        echo("O arquivo não é uma imagem.");
    }

    // Move o arquivo enviado
    if (!move_uploaded_file($_FILES["servicoimg"]["tmp_name"], $target_file)) {
        echo("Desculpe, houve um erro ao inserir seu arquivo.");
    }
}

$sqlInsertServico = "INSERT INTO cadservico VALUES(0, :nome, :valor, :descricao)"; 
$stmt = $conn->prepare($sqlInsertServico);
$stmt->bindValue(':nome', $nome);
$stmt->bindValue(':valor', $valor);
$stmt->bindValue(':descricao', $nomeArquivo);
$stmt->execute();

header("Location: ../administrador/cadServicos.php");
?>
