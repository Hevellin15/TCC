<?php

require_once '../conexao/config.php';

extract($_POST);

$sqlInsertCliente = "INSERT INTO casdastrarcliente VALUES(0, :nome, :email, :senha)"; 
$stmt = $conn->prepare($sqlInsertCliente);
$stmt->bindValue(':nome', $nome);
$stmt->bindValue(':email', $email);
$stmt->bindValue(':senha', $senha);
$stmt->execute();

header("Location: ../servicos.php");
?>


?>