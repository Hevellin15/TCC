<?php

require_once '../conexao/config.php';

extract($_POST);

$sqlAcessarAdm = "INSERT INTO acesso VALUES(0, :email, :senha)"; 
$stmt = $conn->prepare($sqlAcessarAdm);
$stmt->bindValue(':email', $email);
$stmt->bindValue(':senha', $senha);
$stmt->execute();

header("Location: ../administrador/agendaAdm.php");
?>
