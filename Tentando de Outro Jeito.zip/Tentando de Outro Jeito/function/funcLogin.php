<?php

require_once '../conexao/config.php';

extract($_POST);

$sqlLogarCliente = "INSERT INTO logincliente VALUES(0, :email, :senha)"; 
$stmt = $conn->prepare($sqlLogarCliente);
$stmt->bindValue(':email', $email);
$stmt->bindValue(':senha', $senha);
$stmt->execute();

header("Location: ../servicos.php");
?>


?>