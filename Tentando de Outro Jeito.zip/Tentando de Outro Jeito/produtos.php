<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elis Cabeleleira - Sabonetes</title>
    <link rel="stylesheet" href="/Tentando de Outro Jeito/assets/css/produtos.css">
</head>
<body>

    <!-- Cabeçalho -->
    <header>
        <div class="logo">Elis Cabeleleira</div>
        <nav>
            <ul>
                <li><a href="./servicos.php">Serviços</a></li>
                <li><a href="./agenda.php">Agendar</a></li>
                <li><a href="./produtos.php">Produtos</a></li>
            </ul>
        </nav>
        <div class="auth-buttons">
                <button class="signin"><a href="./login.php">Entrar</a></button>
                <button ><a class="register" href="./cadastrar.php">Cadastrar</a></button>
            </div>
    </div>
</header>

    <!-- Banner Principal -->
    <section class="banner" style="background-image: url('/Tentando de Outro Jeito/assets/img/PRODUTOS/8.jpeg');">
        <div>
            <h1>Sabonetes</h1>
            <p>Além de cuidar do seu cabelo, cuide da sua pele também</p>
        </div>
    </section>

    <!-- Sabonetes para o corpo -->
    <section>
        <h2 class="section-title">Sabonetes para o corpo</h2>
        <div class="product-section">
            <div class="product-item">
                <img src="/Tentando de Outro Jeito/assets/img/PRODUTOS/1.jpeg" alt="Sabonete Maracujá">
                <p class="name">Maracujá</p>
                <p class="price">R$10,00</p>
            </div>
            <div class="product-item">
                <img src="/Tentando de Outro Jeito/assets/img/PRODUTOS/2.jpeg" alt="Second Product">
                <p class="name">Product 2</p>
                <p class="price">R$15,00</p>
            </div>
            <div class="product-item">
                <img src="/Tentando de Outro Jeito/assets/img/PRODUTOS/3.jpeg" alt="Third Product">
                <p class="name">Product 3</p>
                <p class="price">R$20,00</p>
            </div>
            <!-- Adicionar mais produtos conforme necessário -->
        </div>
    </section>

    <!-- Sabonetes para o rosto -->
    <section>
        <h2 class="section-title">Sabonetes para o rosto</h2>
        <div class="product-section">
            <div class="product-item">
                <img src="/Tentando de Outro Jeito/assets/img/PRODUTOS/4.jpeg" alt="Featured Product">
                <p class="name">Featured Product</p>
                <p class="price">R$10,00</p>
            </div>
            <div class="product-item">
                <img src="/Tentando de Outro Jeito/assets/img/PRODUTOS/5.jpeg" alt="Barbatimão">
                <p class="name">Barbatimão/Melaleuca</p>
                <p class="price">R$10,00</p>
            </div>
            <div class="product-item">
                <img src="/Tentando de Outro Jeito/assets/img/PRODUTOS/6.jpeg" alt="Third Product">
                <p class="name">Product 6</p>
                <p class="price">R$10,00</p>
            </div>
            <!-- Adicionar mais produtos conforme necessário -->
    <?php
        require_once './conexao/config.php';
        $sql = 'SELECT * FROM cadproduto';
        $stmt = $conn->prepare($sql);
        $stmt->execute();

        if($stmt->rowCount() > 0){
            $lista = $stmt->fetchAll(PDO::FETCH_OBJ);
        }else{
            $lista = [];
        }
        foreach($lista as $produtos){
    ?>
    <div class="product-item">
        <img src="./assets/img/PRODUTOS/<?=$produtos->imagem?>">
        <p class="name"><?=$produtos->nome?></p>
        <p class="price"><?=$produtos->valor?></p>
    </div>
    <?php
    }
    ?>
        </div>
        
    </section>


    <!-- Rodapé -->
    <footer>
        <p>© 2024 - Desenvolvido por Ana Marcele - Hevellin Silva - Isabela Fernanda </p>
        <div class="social-media">
            <a href="#"><img src="./assets/img/redes-sociais/facebook.svg" alt="Facebook"></a>
            <a href="#"><img src="./assets/img/redes-sociais/instagram.svg" alt="Instagram"></a>
            <a href="#"><img src="./assets/img/redes-sociais/twitter.svg" alt="Twitter"></a>
        </div>
    </footer>
</body>
</html>
</html>
