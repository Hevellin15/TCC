<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elis Cabeleleira</title>
    <link rel="stylesheet" href="./assets/css/serviços.css">
</head>
<body>
<style>
    button .sing-in a:link, a:visited {
    background-color: #3d3d3d;
        color: white;
        border: none;
        padding: 10px 20px;
        cursor: pointer;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    }

    a{
            text-decoration: none;
        }
        a:link{
            color: black;
        }
        a:hover{
            color: rgb(8, 43, 78);
        }
    </style>
    
    <!-- Cabeçalho -->
    <header>
        <div class="logo">Elis Cabeleleira</div>
        <div class="nav-auth-container">
            <nav>
                <ul>
                    <li><a href="./servicos.php">Serviços</a></li>
                    <li><a href="./agenda.php">Agendar</a></li>
                    <li><a href="./produtos.php">Produtos</a></li>
                </ul>
            </nav>
            <div class="auth-buttons">
                    <button class="sign-in"><a href="./login.php">Entrar</a></button>
                    <button class="register"><a href="./cadastrar.php">Cadastrar</a></button>
                </div>
        </div>
    </header>

    <!-- Conteúdo principal -->
    <main>
        <h1>O que deseja fazer?</h1>
        <p>Escolha o que gostaria de fazer com seu cabelo</p>
        <div class="services">
            <div class="service-item">
                <img src="./assets/img/PRODUTOS/corte-em-u-v-e-reto.jpg" alt="Corte em U">
                <p class="service-name">Cortes</p>
                <p class="price">R$22,99</p>
            </div>
            <div class="service-item">
                <img src="./assets/img/PRODUTOS/materização.jpg" alt="Matização">
                <p class="service-name">Matização</p>
                <p class="price">R$31,00</p>
            </div>
            <div class="service-item">
                <img src="./assets/img/PRODUTOS/tintura.jpg" alt="Tintura">
                <p class="service-name">Tintura</p>
                <p class="price">R$35,90</p>
            </div>
            <div class="service-item">
                <img src="./assets/img/PRODUTOS/hidratação.jpg" alt="Hidratação Simples">
                <p class="service-name">Hidratação Simples</p>
                <p class="price">R$25,97</p>
            </div>
            <div class="service-item">
                <img src="./assets/img/PRODUTOS/progressiva.jpg" alt="Progressiva">
                <p class="service-name">Progressiva</p>
                <p class="price">R$24,43</p>
            </div>
            <div class="service-item">
                <img src="./assets/img/PRODUTOS/corte,escova.jpg" alt="escova">
                <p class="service-name">Corte e Escova</p>
                <p class="price">R$33,88</p>
            </div>
            <div class="service-item">
                <img src="./assets/img/PRODUTOS/plastica.jpg" alt="plastica">
                <p class="service-name">Plastica de Fios</p>
                <p class="price">R$28,59</p>
            </div>
            <div class="service-item">
                <img src="./assets/img/PRODUTOS/botox.jpg" alt="botox">
                <p class="service-name">Botox Capilar</p>
                <p class="price">R$29,00</p>
            </div>
            <div class="service-item">
                <img src="./assets/img/PRODUTOS/formol.jpg" alt="sem">
                <p class="service-name">Progressiva sem formol</p>
                <p class="price">R$30,63</p>
            </div>
            <div class="service-item">
                <img src="./assets/img/PRODUTOS/selagem.jpg" alt="capilar">
                <p class="service-name">Selagem</p>
                <p class="price">R$34,87</p>
            </div>
        </div>
    </main>

    <!-- Rodapé -->
    <footer>
        <p>© 2024 - Desenvolvido por Ana Marcele - Hevellin Silva - Isabela Fernanda </p>
        <div class="social-media">
            <a href="#"><img src="./assets/img/redes-sociais/facebook.svg" alt="Facebook"></a>
            <a href="#"><img src="./assets/img/redes-sociais/instagram.svg" alt="Instagram"></a>
            <a href="#"><img src="./assets/img/redes-sociais/twitter.svg" alt="Twitter"></a>
        </div>
    </footer>
</body>
</html>