<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Login</title>
    <link rel="stylesheet" href="./assets/css/login.css">
</head>
<body>

    <!-- <button onclick="history.back()">Go Back</button> -->
    <div class="container">
        <div class="left">
            <h1>Bem Vindo de Volta!!</h1>
            <form action="./function/funcLogin.php" method="post">
                <div class="input-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" placeholder="Email">
                </div>
                <div class="input-group">
                    <label for="password">Senha</label>
                    <input type="password" name="senha" placeholder="Senha">
                </div>
                <button type="submit" class="login-btn">Acessar</button>
                <a href="#" class="forgot-password">Esqueceu a senha?</a>
            </form>
        </div>
        <div class="right">
            <div class="image-container">
                <img src="./assets/img/login.png" alt="login">
            </div>
        </div>
    </div>

