<?php

$hostname = "localhost";
$dbname = "agendamrentosalao";
$username = "root"; 
$password = ""; 

// try {
    $conn = new PDO("mysql:host=$hostname;dbname=$dbname", $username, $password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
//     echo "Conexão realizada com sucesso";
// } catch (PDOException $e) {
//     echo "Erro na conexão: " . $e->getMessage();
// }

?>

