<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar</title>
    <link rel="stylesheet" href="./assets/css/cad.css">
</head>
<body>
        <img src="./assets/img/cadastro.jpeg" alt="cad">
        <div class="content">
                <h2 class="tittle">Crie uma conta</h2>
                <p class="description">Coloque seu email para se cadastrar</p>
                <form action="./function/funcCadastro.php" method="post">
                    <input type="text" name="nome" placeholder="Nome">
                    <input type="email" name="email" placeholder="E-mail">
                    <input type="password" name="senha" placeholder="Senha">
                    <button type= "submit" class="btn">Cadastrar</button>
                </form>
    </div>
</body>
</html>

<!-- <!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar</title>
    <link rel="stylesheet" href="./assets/css/cad.css">
</head>
<body>
    <div class="container">
        <div class="imagem">
            <img src="./assets/img/cadastro.jpeg" alt="">
        </div>
    </div>
        <div class="content first content">
            <div class="second colum">
                <h2 class="tittle">Crie uma conta</h2>
                <p class="description">Coloque seu email para se cadastrar</p>
                <form action="./function/funcCadastro.php" method="post">

                    <input type="text" placeholder="Nome" name="nome">
                    <input type="email" placeholder="Email" name="email">
                    <input type="password" placeholder="Senha" name="senha">

                    <button class="btn">Cadastrar</button>

                    <p class="description">ou continue com o Google</p>
                <div class="social-midia">
                    <ul class="list-social-midia">
                        <li><a href="#">Google</a></li>
                    </ul>
                </div>
                </form>
            </div>
    </div>
</body>
</html> -->