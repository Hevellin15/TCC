<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Agendamento</title>
  <link rel="stylesheet" href="./assets/css/agenda.css">
</head>
<body>
<style>
  button .sing-in a:link, a:visited {
  background-color: #3d3d3d;
    color: white;
    border: none;
    padding: 10px 20px;
    cursor: pointer;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

</style>
  <!-- Cabeçalho -->
  <header>
    <div class="logo">Elis Cabeleleira</div>
    <div class="nav-auth-container">
        <nav>
            <ul>
                <li><a href="./servicos.php">Serviços</a></li>
                <li><a href="./agenda.php">Agendar</a></li>
                <li><a href="./produtos.php">Produtos</a></li>
            </ul>
        </nav>
        <div class="auth-buttons">
                <button class="sign-in"><a href="./login.php">Entrar</a></button>
                <button class="register"><a href="./cadastrar.php">Cadastrar</a></button>
            </div>
    </div>
</header>

  <div class="container">
    <form action="./function/funcAgenda.php" method="post" id="cads">
      <h4>Agendamento</h4>
      <hr>
      <h4>Horário da Sessão</h4>
      <div class="input-group">
        <p>Horário</p>
        <input type="time" name="horario" placeholder="HH">
      </div>

      <div class="input-group">
        <p>Dia</p>
        <input type="date" name="dia" placeholder="Dia">
      </div>
      <hr>
      <label>O que irá fazer</label>
      <input type="text" name="servico" placeholder="Coloque o que deseja fazer">

      <label>Telefone</label>
      <input type="text" name="telefone" placeholder="Coloque o telefone">

      <label>Email</label>
      <input type="text" name="email" placeholder="Coloque o email">

      <button type="button" class="save-btn"
      onclick="myFunction()">
      <span class="icon">💾</span> Salvar Agendamento
      </button> <p id="demo"></p>
      <script>

  function myFunction() {
    let x = document.getElementById("cads");
    let text;
    if (x == '' ) {
      text = "Input not valid";
    } else {
      text = "Castrado com sucesso!";
    }
    document.getElementById("demo").innerHTML = text;
    document.getElementById("demo").style.color = 'blue';
  }
  </script>
  </form>
  </div>
  <!-- Rodapé -->
  <footer>
    <p>© 2024 - Desenvolvido por Ana Marcele - Hevellin Silva - Isabela Fernanda </p>
    <div class="social-media">
        <a href="#"><img src="./assets/img/redes-sociais/facebook.svg" alt="Facebook"></a>
        <a href="#"><img src="./assets/img/redes-sociais/instagram.svg" alt="Instagram"></a>
        <a href="#"><img src="./assets/img/redes-sociais/twitter.svg" alt="Twitter"></a>
    </div>
</footer>

</body>
</html>